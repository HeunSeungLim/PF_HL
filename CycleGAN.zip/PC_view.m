clc; clear; close all;

% path = 'U:\git\PF-Net-Point-Fractal-Network-master\PF-Net-Point-Fractal-Network-master\test_one\';
path = '.\';

% inputa = readmatrix(strcat(path, 'fake.txt'));
% inputb = readmatrix(strcat(path, 'real4-1.csv'));
% % inputa = readmatrix(strcat(path, 'crop4-1.csv'));
inputa = readmatrix(strcat(path, 'input_cropped1_a.txt'));
inputb = readmatrix(strcat(path, 'input_cropped1_b.txt'));
outputa = readmatrix(strcat(path, 'fake_out_a.txt'));
outputb = readmatrix(strcat(path, 'fake_out_b.txt'));
recona = readmatrix(strcat(path, 'fake_recon_a.txt'));
reconb = readmatrix(strcat(path, 'fake_recon_b.txt'));
% % % real_point = readmatrix(strcat(path, 'real_point.txt'));
% % 
% % 
% % % realcenter = readmatrix(strcat(path, 'real_point.txt'));
% % % figure; pcshow(pointCloud(real_point));
% % % reconb = readmatrix(strcat(path, 'fake_out_b.txt'));
figure; pcshow(pointCloud(inputa), 'MarkerSize', 100);
figure; pcshow(pointCloud(inputb), 'MarkerSize', 100);
figure; pcshow(pointCloud(outputa), 'MarkerSize', 100);
figure; pcshow(pointCloud(outputb), 'MarkerSize', 100);
figure; pcshow(pointCloud(recona), 'MarkerSize', 100);
figure; pcshow(pointCloud(reconb), 'MarkerSize', 100);

% % figure; pcshow(pointCloud(realcenter));
% merge_in_out = zeros(2048, 3);
% 
% merge_in_out(1:1535, :) = input(1:1535, :);
% merge_in_out(1536:end-1, :) = output(1:end,  :);

% point_in_out = pointCloud(merge_in_out);
% point_out = pointCloud(output);



% pcshow(point_in_out);














