#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from model import *
from dataset import *
import random
import itertools
from statistics import mean
from torch.autograd import Variable
import torch
import torch.nn as nn

from torchvision import transforms
from torch.utils.tensorboard import SummaryWriter
import matplotlib.pyplot as plt

import utils
from utils import PointLoss
from utils import distance_squre
import data_utils as d_utils
import ModelNet40Loader
import shapenet_part_loader
# from model_PFNet import _netlocalD,_netG
from PFNet_HL import _netlocalD, _netG
from utils import PointLoss
from utils import distance_squre

class Train:
    def __init__(self, args):
        self.mode = args.mode
        self.train_continue = args.train_continue

        self.scope = args.scope
        self.dir_checkpoint = args.dir_checkpoint
        self.dir_log = args.dir_log

        self.dir_data = args.dir_data
        self.dir_result = args.dir_result

        self.num_epoch = args.num_epoch
        self.batch_size = args.batch_size

        self.lr_G = args.lr_G
        self.lr_D = args.lr_D

        self.wgt_c_a = args.wgt_c_a
        self.wgt_c_b = args.wgt_c_b
        self.wgt_i = args.wgt_i

        self.optim = args.optim
        self.beta1 = args.beta1

        self.ny_in = args.ny_in
        self.nx_in = args.nx_in
        self.nch_in = args.nch_in

        self.ny_load = args.ny_load
        self.nx_load = args.nx_load
        self.nch_load = args.nch_load

        self.ny_out = args.ny_out
        self.nx_out = args.nx_out
        self.nch_out = args.nch_out

        self.nch_ker = args.nch_ker

        self.data_type = args.data_type
        self.norm = args.norm

        self.gpu_ids = args.gpu_ids

        self.num_freq_disp = args.num_freq_disp
        self.num_freq_save = args.num_freq_save

        self.direction = args.direction
        self.name_data = args.name_data

        self.nblk = args.nblk

        if self.gpu_ids and torch.cuda.is_available():
            self.device = torch.device("cuda:%d" % self.gpu_ids[0])
            torch.cuda.set_device(self.gpu_ids[0])
        else:
            self.device = torch.device("cpu")

    def save(self, dir_chck, netG_a2b, netG_b2a, netD_a, netD_b, optimG, optimD, epoch):
        if not os.path.exists(dir_chck):
            os.makedirs(dir_chck)

        torch.save({'netG_a2b': netG_a2b.state_dict(), 'netG_b2a': netG_b2a.state_dict(),
                    'netD_a': netD_a.state_dict(), 'netD_b': netD_b.state_dict(),
                    'optimG': optimG.state_dict(), 'optimD': optimD.state_dict()},
                   '%s/model_epoch%04d.pth' % (dir_chck, epoch))

    def load(self, dir_chck, netG_a2b, netG_b2a, netD_a=[], netD_b=[], optimG=[], optimD=[], epoch=[], mode='train'):
        if not epoch:
            ckpt = os.listdir(dir_chck)
            ckpt.sort()
            epoch = int(ckpt[-1].split('epoch')[1].split('.pth')[0])

        dict_net = torch.load('%s/model_epoch%04d.pth' % (dir_chck, epoch))

        print('Loaded %dth network' % epoch)

        if mode == 'train':
            netG_a2b.load_state_dict(dict_net['netG_a2b'])
            netG_b2a.load_state_dict(dict_net['netG_b2a'])
            netD_a.load_state_dict(dict_net['netD_a'])
            netD_b.load_state_dict(dict_net['netD_b'])
            optimG.load_state_dict(dict_net['optimG'])
            optimD.load_state_dict(dict_net['optimD'])

            return netG_a2b, netG_b2a, netD_a, netD_b, optimG, optimD, epoch

        elif mode == 'test':
            netG_a2b.load_state_dict(dict_net['netG_a2b'])
            netG_b2a.load_state_dict(dict_net['netG_b2a'])

            return netG_a2b, netG_b2a, epoch

    def preprocess(self, data):
        normalize = Normalize()
        randflip = RandomFlip()
        rescale = Rescale((self.ny_load, self.nx_load))
        randomcrop = RandomCrop((self.ny_out, self.nx_out))
        totensor = ToTensor()
        return totensor(randomcrop(rescale(randflip(normalize(data)))))

    def deprocess(self, data):
        tonumpy = ToNumpy()
        denomalize = Denomalize()
        return denomalize(tonumpy(data))

    def train(self):
        mode = self.mode

        train_continue = self.train_continue
        num_epoch = self.num_epoch

        lr_G = self.lr_G
        lr_D = self.lr_D

        wgt_c_a = self.wgt_c_a
        wgt_c_b = self.wgt_c_b
        wgt_i = self.wgt_i

        batch_size = self.batch_size
        device = self.device

        gpu_ids = self.gpu_ids

        nch_in = self.nch_in
        nch_out = self.nch_out
        nch_ker = self.nch_ker

        norm = self.norm
        name_data = self.name_data

        num_freq_disp = self.num_freq_disp
        num_freq_save = self.num_freq_save

        ## setup dataset
        dir_chck = os.path.join(self.dir_checkpoint, self.scope, name_data)

        dir_data_train = os.path.join(self.dir_data, name_data, 'train')

        dir_log_train = os.path.join(self.dir_log, self.scope, name_data, 'train')

        transform_train = transforms.Compose([Normalize(), RandomFlip(), Rescale((self.ny_load, self.nx_load)), RandomCrop((self.ny_in, self.nx_in)), ToTensor()])
        transform_inv = transforms.Compose([ToNumpy(), Denomalize()])

        # dataset_train = Dataset(dir_data_train, direction=self.direction, data_type=self.data_type, transform=transform_train)

        dset = shapenet_part_loader.PartDataset(root='./dataset/shapenetcore_partanno_segmentation_benchmark_v0/',
                                                classification=True, class_choice=None, npoints=2048, split='train')
        assert dset

        dataloader = torch.utils.data.DataLoader(dset, batch_size=2, shuffle=True, num_workers=2)

        num_train = len(dataloader)

        num_batch_train = int((num_train / 2) + ((num_train % 2) != 0))

        ## setup network
        # netG_a2b = UNet(nch_in, nch_out, nch_ker, norm)
        # netG_b2a = UNet(nch_in, nch_out, nch_ker, norm)
        # netG_a2b = ResNet(nch_in, nch_out, nch_ker, norm, nblk=self.nblk)
        # netG_b2a = ResNet(nch_in, nch_out, nch_ker, norm, nblk=self.nblk)
        netG_a2b = _netG(3, 1, [2048, 1024, 512], 2048)
        netG_b2a = _netG(3, 1, [2048, 1024, 512], 2048)

        # netD_a = Discriminator(nch_in, nch_ker, norm)
        # netD_b = Discriminator(nch_in, nch_ker, norm)
        netD_a = _netlocalD(2048)
        netD_b = _netlocalD(2048)
        
        init_net(netG_a2b, init_type='normal', init_gain=0.02, gpu_ids=gpu_ids)
        init_net(netG_b2a, init_type='normal', init_gain=0.02, gpu_ids=gpu_ids)

        init_net(netD_a, init_type='normal', init_gain=0.02, gpu_ids=gpu_ids)
        init_net(netD_b, init_type='normal', init_gain=0.02, gpu_ids=gpu_ids)

        ## setup loss & optimization
        fn_Cycle = nn.L1Loss().to(device)   # L1
        fn_GAN = nn.BCEWithLogitsLoss().to(device)
        criterion_PointLoss = PointLoss().to(device)
        fn_Ident = nn.L1Loss().to(device)   # L1
        netG_a2b = torch.nn.DataParallel(netG_a2b)
        netG_b2a = torch.nn.DataParallel(netG_b2a)
        netD_a = torch.nn.DataParallel(netD_a)
        netD_b = torch.nn.DataParallel(netD_b)

        def weights_init_normal(m):
            classname = m.__class__.__name__
            if classname.find("Conv2d") != -1:
                torch.nn.init.normal_(m.weight.data, 0.0, 0.02)
            elif classname.find("Conv1d") != -1:
                torch.nn.init.normal_(m.weight.data, 0.0, 0.02)
            elif classname.find("BatchNorm2d") != -1:
                torch.nn.init.normal_(m.weight.data, 1.0, 0.02)
                torch.nn.init.constant_(m.bias.data, 0.0)
            elif classname.find("BatchNorm1d") != -1:
                torch.nn.init.normal_(m.weight.data, 1.0, 0.02)
                torch.nn.init.constant_(m.bias.data, 0.0)


        netG_a2b.to(device)
        netG_a2b.apply(weights_init_normal)
        netG_b2a.to(device)
        netG_b2a.apply(weights_init_normal)

        netD_a.to(device)
        netD_a.apply(weights_init_normal)
        netD_b.to(device)
        netD_b.apply(weights_init_normal)

        paramsG_a2b = netG_a2b.parameters()
        paramsG_b2a = netG_b2a.parameters()
        paramsD_a = netD_a.parameters()
        paramsD_b = netD_b.parameters()

        optimG = torch.optim.Adam(itertools.chain(paramsG_a2b, paramsG_b2a), lr=lr_G, betas=(self.beta1, 0.999))
        optimD = torch.optim.Adam(itertools.chain(paramsD_a, paramsD_b), lr=lr_D, betas=(self.beta1, 0.999))

        real_label = 1
        fake_label = 0

        crop_point_num = int(512)
        input_cropped1 = torch.FloatTensor(2, 2048, 3)
        label = torch.FloatTensor(1)


        # schedG = get_scheduler(optimG, self.opts)
        # schedD = get_scheduler(optimD, self.opts)

        # schedG = torch.optim.lr_scheduler.ExponentialLR(optimG, gamma=0.9)
        # schedD = torch.optim.lr_scheduler.ExponentialLR(optimD, gamma=0.9)

        ## load from checkpoints
        st_epoch = 0

        if train_continue == 'on':
            netG_a2b, netG_b2a, netD_a, netD_b, optimG, optimD, st_epoch = \
                self.load(dir_chck, netG_a2b, netG_b2a, netD_a, netD_b, optimG, optimD, mode=mode)

        ## setup tensorboard
        # writer_train = SummaryWriter(log_dir=dir_log_train)

        for epoch in range(st_epoch + 1, num_epoch + 1):
            ## training phase
            if epoch<30:
                alpha1 = 0.01
                alpha2 = 0.02
            elif epoch<80:
                alpha1 = 0.05
                alpha2 = 0.1
            else:
                alpha1 = 0.1
                alpha2 = 0.2


            loss_G_a2b_train = []
            loss_G_b2a_train = []
            loss_D_a_train = []
            loss_D_b_train = []
            loss_C_a_train = []
            loss_C_b_train = []
            loss_CD = []
            loss_I_a_train = []
            loss_I_b_train = []

            for i, data in enumerate(dataloader, 0):

                real_point, target = data
                real_point_b = real_point

                batch_size = real_point.size()[0]
                # real_center = torch.FloatTensor(24, 1, 512, 3)
                real_center = torch.FloatTensor(2, 1, 2048, 3)
                input_cropped1_a = torch.FloatTensor(2, 2048, 3)
                input_cropped1_a = input_cropped1_a.data.copy_(real_point)
                input_cropped1_b = torch.FloatTensor(2, 2048, 3)
                input_cropped1_b = input_cropped1_b.data.copy_(real_point)
                real_point = torch.unsqueeze(real_point, 1)
                input_cropped1_a = torch.unsqueeze(input_cropped1_a, 1)
                input_cropped1_b = torch.unsqueeze(input_cropped1_b, 1)

                # np.savetxt('./pre_set' + '.txt', input_cropped1[0, 0, :, :], fmt="%f,%f,%f")

                p_origin = [0, 0, 0]
                cropmethod = 'random_center'
                if cropmethod == 'random_center':
                    # Set viewpoints
                    choice = [torch.Tensor([1, 0, 0]), torch.Tensor([0, 0, 1]), torch.Tensor([1, 0, 1]),
                              torch.Tensor([-1, 0, 0]), torch.Tensor([-1, 1, 0])]
                    for m in range(batch_size):
                        index = random.sample(choice, 1)  # Random choose one of the viewpoint
                        distance_list = []
                        p_center = index[0]
                        for n in range(2048):
                            distance_list.append(distance_squre(real_point[m, 0, n], p_center))
                            # real_center.data[m, 0, n,:] = torch.FloatTensor([0, 0, 0])
                            input_cropped1_b.data[m, 0, n, :] = torch.FloatTensor([0, 0, 0])
                        distance_order = sorted(enumerate(distance_list), key=lambda x: x[1])

                        for sp in range(512):
                            input_cropped1_a.data[m, 0, distance_order[sp][0]] = torch.FloatTensor([0, 0, 0])
                            input_cropped1_b.data[m, 0, distance_order[sp][0]] = real_point[m, 0, distance_order[sp][0]]

                            real_center.data[m, 0, sp] = real_point[m, 0, distance_order[sp][0]]

                label.resize_([batch_size, 1]).fill_(real_label)
                real_point = real_point.to(device)
                real_center = real_center.to(device)

                input_cropped1_a = input_cropped1_a.to(device)
                input_cropped1_b = input_cropped1_b.to(device)
                label = label.to(device)
                ############################
                # (1) data prepare
                ###########################
                real_center = Variable(real_center, requires_grad=True)
                real_center = torch.squeeze(real_center, 1)
                real_center_key1_idx = utils.farthest_point_sample(real_center, 64, RAN=False)
                real_center_key1 = utils.index_points(real_center, real_center_key1_idx)
                real_center_key1 = Variable(real_center_key1, requires_grad=True)

                real_center_key2_idx = utils.farthest_point_sample(real_center, 128, RAN=True)
                real_center_key2 = utils.index_points(real_center, real_center_key2_idx)
                real_center_key2 = Variable(real_center_key2, requires_grad=True)
                real_center_key = [real_center, real_center_key1, real_center_key2]

                input_cropped1_a = torch.squeeze(input_cropped1_a, 1)
                input_cropped2_idx = utils.farthest_point_sample(input_cropped1_a, 1024, RAN=True)
                input_cropped2_a = utils.index_points(input_cropped1_a, input_cropped2_idx)
                input_cropped3_idx = utils.farthest_point_sample(input_cropped1_a, 512, RAN=False)
                input_cropped3_a = utils.index_points(input_cropped1_a, input_cropped3_idx)
                input_cropped1_a = Variable(input_cropped1_a, requires_grad=True)
                input_cropped2_a = Variable(input_cropped2_a, requires_grad=True)
                input_cropped3_a = Variable(input_cropped3_a, requires_grad=True)
                input_cropped2_a = input_cropped2_a.to(device)
                input_cropped3_a = input_cropped3_a.to(device)
                input_cropped_a = [input_cropped1_a, input_cropped2_a, input_cropped3_a]

                input_cropped1_b = torch.squeeze(input_cropped1_b, 1)
                input_cropped2_idx = utils.farthest_point_sample(input_cropped1_b, 1024, RAN=True)
                input_cropped2_b = utils.index_points(input_cropped1_b, input_cropped2_idx)
                input_cropped3_idx = utils.farthest_point_sample(input_cropped1_b, 512, RAN=False)
                input_cropped3_b = utils.index_points(input_cropped1_b, input_cropped3_idx)
                input_cropped1_b = Variable(input_cropped1_b, requires_grad=True)
                input_cropped2_b = Variable(input_cropped2_b, requires_grad=True)
                input_cropped3_b = Variable(input_cropped3_b, requires_grad=True)
                input_cropped2_b = input_cropped2_b.to(device)
                input_cropped3_b = input_cropped3_b.to(device)
                input_cropped_b = [input_cropped1_b, input_cropped2_b, input_cropped3_b]




                netG_a2b.train()
                netG_b2a.train()
                netD_a.train()
                netD_b.train()

                # optimG.zero_grad()


                # forward netG
                # fake_center1_out_b, fake_center2_out_b, fake_out_b = netG_a2b(input_cropped_a)
                # fake_center1_out_a, fake_center2_out_a, fake_out_a = netG_b2a(input_cropped_b)
                fake_out_b = netG_a2b([input_cropped1_a])
                fake_out_a = netG_b2a([input_cropped1_b])

                real_center_b = torch.FloatTensor(2, 1, 2048, 3)
                output_cropped1_a = torch.FloatTensor(2, 2048, 3)
                output_cropped1_a = output_cropped1_a.data.copy_(real_point_b)
                output_cropped1_b = torch.FloatTensor(2, 2048, 3)
                output_cropped1_b = output_cropped1_b.data.copy_(real_point_b)
                real_point_b = torch.unsqueeze(real_point_b, 1)
                output_cropped1_a = torch.unsqueeze(output_cropped1_a, 1)
                output_cropped1_b = torch.unsqueeze(output_cropped1_b, 1)


                if cropmethod == 'random_center':
                    # Set viewpoints
                    choice = [torch.Tensor([1, 0, 0]), torch.Tensor([0, 0, 1]), torch.Tensor([1, 0, 1]),
                              torch.Tensor([-1, 0, 0]), torch.Tensor([-1, 1, 0])]
                    for m in range(batch_size):
                        index = random.sample(choice, 1)  # Random choose one of the viewpoint
                        distance_list = []
                        p_center = index[0]
                        for n in range(2048):
                            distance_list.append(distance_squre(real_point_b[m, 0, n], p_center))
                            real_center_b.data[m, 0, n,:] = torch.FloatTensor([0, 0, 0])

                            output_cropped1_a.data[m, 0, n, :] = torch.FloatTensor([0, 0, 0])
                            output_cropped1_b.data[m, 0, n, :] = torch.FloatTensor([0, 0, 0])
                        for temp in range(2048):
                            output_cropped1_a.data[m, 0, distance_order[temp][0], :] = fake_out_a[m, distance_order[temp][0], :]
                            output_cropped1_b.data[m, 0, distance_order[temp][0], :] = fake_out_b[m, distance_order[temp][0], :]
                            # output_cropped1_a.data[m, 0, distance_order[temp][0], :] = fake_out_a[m, temp, :]
                            # output_cropped1_b.data[m, 0, distance_order[temp][0], :] = fake_out_b[m, temp, :]
                        # for temp in range(512, 1536):
                        #     output_cropped1_b.data[m, 0, distance_order[temp][0], :] = fake_out_b[m, distance_order[temp][0], :]
                        # distance_order = sorted(enumerate(distance_list), key=lambda x: x[1])


                    # np.savetxt('./output_cropped1_a' + '.txt', real_point[0, 0, :, :].cpu().detach().numpy(),
                    #                fmt="%f,%f,%f")  # reference
                        # for sp in range(512):
                        #     output_cropped1_a.data[m, 0, distance_order[sp][0]] = torch.FloatTensor([0, 0, 0])
                        #     output_cropped1_b.data[m, 0, sp] = real_point_b[m, 0, distance_order[sp][0]]
                        #
                        #     real_center_b.data[m, 0, sp] = real_point_b[m, 0, distance_order[sp][0]]


                # for m in range(batch_size):
                #     for sp in range(512, 0):
                #         output_cropped1_a.data[m, sp, :] = fake_out_b[m, sp, :]
                #         output_cropped1_b.data[m, sp, :] = fake_out_a[m, sp, :]

                        # real_center.data[m, 0, sp] = real_point[m, 0, distance_order[sp][0]]

                # np.savetxt('./pre_set' + '.txt', input_cropped1[0, 0, :, :], fmt="%f,%f,%f")

                # np.savetxt('./output_cropped1_a' + '.txt', fake_out_a[ 0, :, :].cpu().detach().numpy(),
                #            fmt="%f,%f,%f")  # output_A
                # np.savetxt('./output_cropped1_b' + '.txt', fake_out_b[ 0, :, :].cpu().detach().numpy(),
                #            fmt="%f,%f,%f")  # out_B


                output_cropped1_a = output_cropped1_a.to(device)
                output_cropped1_b = output_cropped1_b.to(device)

                fake_out_a = torch.squeeze(fake_out_a, 1)
                output_cropped2_idx = utils.farthest_point_sample(fake_out_a, 1024, RAN=True)
                output_cropped2_a = utils.index_points(fake_out_a, output_cropped2_idx)
                output_cropped3_idx = utils.farthest_point_sample(fake_out_a, 512, RAN=False)
                output_cropped3_a = utils.index_points(fake_out_a, output_cropped3_idx)
                output_cropped1_a = Variable(fake_out_a, requires_grad=True)
                output_cropped2_a = Variable(output_cropped2_a, requires_grad=True)
                output_cropped3_a = Variable(output_cropped3_a, requires_grad=True)
                output_cropped2_a = output_cropped2_a.to(device)
                output_cropped3_a = output_cropped3_a.to(device)
                output_cropped_a = [output_cropped1_a, output_cropped2_a, output_cropped3_a]

                fake_out_b = torch.squeeze(fake_out_b, 1)
                output_cropped2_idx = utils.farthest_point_sample(fake_out_b, 1024, RAN=True)
                output_cropped2_b = utils.index_points(fake_out_b, output_cropped2_idx)
                output_cropped3_idx = utils.farthest_point_sample(fake_out_b, 512, RAN=False)
                output_cropped3_b = utils.index_points(fake_out_b, output_cropped3_idx)
                output_cropped1_b = Variable(fake_out_b, requires_grad=True)
                output_cropped2_b = Variable(output_cropped2_b, requires_grad=True)
                output_cropped3_b = Variable(output_cropped3_b, requires_grad=True)
                output_cropped2_b = output_cropped2_b.to(device)
                output_cropped3_b = output_cropped3_b.to(device)
                output_cropped_b = [output_cropped1_b, output_cropped2_b, output_cropped3_b]



                # fake_center1_recon_b,fake_center2_recon_b,fake_recon_b = netG_a2b(output_cropped_a)
                # fake_center1_recon_a,fake_center2_recon_a,fake_recon_a = netG_b2a(output_cropped_b)

                # np.savetxt('./output_cropped_a' + '.txt', output_cropped_a[0,:,:].cpu().detach().numpy(),
                #            fmt="%f,%f,%f")  # input_A
                # np.savetxt('./fake_out_b' + '.txt', fake_out_b[0, :, :].cpu().detach().numpy(),
                #            fmt="%f,%f,%f")  # input_B

                # fake_center1_recon_b, fake_center2_recon_b, fake_recon_b = netG_a2b(fake_out_a)
                # fake_center1_recon_a, fake_center2_recon_a, fake_recon_a = netG_b2a(fake_out_b)
                fake_recon_b = netG_a2b([fake_out_a])
                fake_recon_a = netG_b2a([fake_out_b])


                # backward netD
                set_requires_grad([netD_a, netD_b], True)
                optimD.zero_grad()

                # backward netD_a




                input_cropped1_a_temp = torch.unsqueeze(input_cropped1_a, 1)
                fake_out_a_temp = torch.unsqueeze(fake_out_a, 1)
                pred_real_a = netD_a(input_cropped1_a_temp)
                pred_fake_a = netD_a(fake_out_a_temp.detach())

                loss_D_a_real = fn_GAN(pred_real_a, torch.ones_like(pred_real_a))
                loss_D_a_fake = fn_GAN(pred_fake_a, torch.zeros_like(pred_fake_a))
                loss_D_a = 0.5 * (loss_D_a_real + loss_D_a_fake)

                # backward netD_b

                input_cropped1_b_temp = torch.unsqueeze(input_cropped1_b, 1)
                fake_out_b_temp = torch.unsqueeze(fake_out_b, 1)
                pred_real_b = netD_b(input_cropped1_b_temp)
                pred_fake_b = netD_b(fake_out_b_temp.detach())

                loss_D_b_real = fn_GAN(pred_real_b, torch.ones_like(pred_real_b))
                loss_D_b_fake = fn_GAN(pred_fake_b, torch.zeros_like(pred_fake_b))
                loss_D_b = 0.5 * (loss_D_b_real + loss_D_b_fake)

                # backward netD
                loss_D = loss_D_a + loss_D_b
                loss_D.backward()
                optimD.step()

                # backward netG
                set_requires_grad([netD_a, netD_b], False)
                optimG.zero_grad()



                pred_fake_a = netD_a(fake_out_a_temp)
                pred_fake_b = netD_b(fake_out_b_temp)

                # recon_cropped1_a = torch.FloatTensor(2, 2048, 3)
                # recon_cropped1_a = recon_cropped1_a.data.copy_(torch.squeeze(real_point_b, 1))
                # recon_cropped1_b = torch.FloatTensor(2, 2048, 3)
                # recon_cropped1_b = recon_cropped1_b.data.copy_(torch.squeeze(real_point_b, 1))
                # recon_cropped1_a = torch.unsqueeze(recon_cropped1_a, 1)
                # recon_cropped1_b = torch.unsqueeze(recon_cropped1_b, 1)
                #
                # recon_cropped2_a = torch.FloatTensor(2, 2048, 3)
                # recon_cropped2_a = recon_cropped2_a.data.copy_(torch.squeeze(real_point_b, 1))
                # recon_cropped2_b = torch.FloatTensor(2, 2048, 3)
                # recon_cropped2_b = recon_cropped2_b.data.copy_(torch.squeeze(real_point_b, 1))
                # recon_cropped2_a = torch.unsqueeze(recon_cropped2_a, 1)
                # recon_cropped2_b = torch.unsqueeze(recon_cropped2_b, 1)
                #
                # recon_cropped3_a = torch.FloatTensor(2, 2048, 3)
                # recon_cropped3_a = recon_cropped3_a.data.copy_(torch.squeeze(real_point_b, 1))
                # recon_cropped3_b = torch.FloatTensor(2, 2048, 3)
                # recon_cropped3_b = recon_cropped3_b.data.copy_(torch.squeeze(real_point_b, 1))
                # recon_cropped3_a = torch.unsqueeze(recon_cropped3_a, 1)
                # recon_cropped3_b = torch.unsqueeze(recon_cropped3_b, 1)
                #
                #
                # for m in range(batch_size):
                #     for n in range(2048):
                #         # distance_list.append(distance_squre(real_point_b[m, 0, n], p_center))
                #         # real_center_b.data[m, 0, n,:] = torch.FloatTensor([0, 0, 0])
                #
                #         recon_cropped1_a.data[m, 0, n, :] = torch.FloatTensor([0, 0, 0])
                #         recon_cropped1_b.data[m, 0, n, :] = torch.FloatTensor([0, 0, 0])
                #         recon_cropped2_a.data[m, 0, n, :] = torch.FloatTensor([0, 0, 0])
                #         recon_cropped2_b.data[m, 0, n, :] = torch.FloatTensor([0, 0, 0])
                #         recon_cropped3_a.data[m, 0, n, :] = torch.FloatTensor([0, 0, 0])
                #         recon_cropped3_b.data[m, 0, n, :] = torch.FloatTensor([0, 0, 0])
                #     for sp in range(512):
                #         recon_cropped1_a.data[m, 0, :] = fake_recon_b[m, 0, :]
                #         recon_cropped1_b.data[m, 0, :] = fake_recon_a[m, 0, :]
                #         recon_cropped2_a.data[m, 0, :] = fake_center2_recon_b[m, 0, :]
                #         recon_cropped2_b.data[m, 0, :] = fake_center2_recon_a[m, 0, :]
                #         recon_cropped3_a.data[m, 0, :] = fake_center1_recon_b[m, 0, :]
                #         recon_cropped3_b.data[m, 0, :] = fake_center1_recon_a[m, 0, :]


                loss_G_a2b = fn_GAN(pred_fake_b, torch.ones_like(pred_fake_b))
                loss_G_b2a = fn_GAN(pred_fake_a, torch.ones_like(pred_fake_a))

                # recon_cropped1_a = recon_cropped1_a.to(device)
                # recon_cropped1_b = recon_cropped1_b.to(device)
                # recon_cropped2_a = recon_cropped2_a.to(device)
                # recon_cropped2_b = recon_cropped2_b.to(device)
                # recon_cropped3_a = recon_cropped3_a.to(device)
                # recon_cropped3_b = recon_cropped3_b.to(device)

                # loss_C_a = fn_Cycle(input_cropped1_a, recon_cropped1_a)
                # loss_C_b = fn_Cycle(input_cropped1_b, recon_cropped1_b)

                # loss_C_a = criterion_PointLoss(torch.squeeze(input_cropped1_a, 1), (fake_recon_b))
                # loss_C_b = criterion_PointLoss(torch.squeeze(input_cropped1_b, 1), (fake_recon_a))


                # if cropmethod == 'random_center':
                #     # Set viewpoints
                #     choice = [torch.Tensor([1, 0, 0]), torch.Tensor([0, 0, 1]), torch.Tensor([1, 0, 1]),
                #               torch.Tensor([-1, 0, 0]), torch.Tensor([-1, 1, 0])]
                # for m in range(batch_size):
                #     index = random.sample(choice, 1)  # Random choose one of the viewpoint
                #     distance_list = []
                #     p_center = index[0]
                #     for n in range(2048):
                #         distance_list.append(distance_squre(real_point[m, 0, n], p_center))
                #             # real_center.data[m, 0, n,:] = torch.FloatTensor([0, 0, 0])
                #         input_cropped1_b.data[m, 0, n, :] = torch.FloatTensor([0, 0, 0])
                #     distance_order = sorted(enumerate(distance_list), key=lambda x: x[1])

                # for sp in range(2048):
                #     fake_recon_b.data[m, distance_order[sp][0], :] = torch.FloatTensor([0, 0, 0])
                #     fake_recon_a.data[m, distance_order[sp][0], :] = torch.FloatTensor([0, 0, 0])

                        # real_center.data[m, 0, sp] = real_point[m, 0, distance_order[sp][0]]

                # [input_cropped1_a, input_cropped2_a, input_cropped3_a]
                # loss_C_a = criterion_PointLoss(fake_recon_b, input_cropped1_b)

                # real_center = torch.squeeze(input_cropped1_b, 1)
                real_center_key1_idx_b = utils.farthest_point_sample(input_cropped1_b, 64, RAN=False)
                real_center_key1_b = utils.index_points(input_cropped1_b, real_center_key1_idx_b)
                real_center_key1_b = Variable(real_center_key1_b, requires_grad=True)

                real_center_key2_idx_b = utils.farthest_point_sample(input_cropped1_b, 128, RAN=True)
                real_center_key2_b = utils.index_points(input_cropped1_b, real_center_key2_idx_b)
                real_center_key2_b = Variable(real_center_key2_b, requires_grad=True)

                real_center_key1_idx_a = utils.farthest_point_sample(input_cropped1_a, 64, RAN=False)
                real_center_key1_a = utils.index_points(input_cropped1_a, real_center_key1_idx_a)
                real_center_key1_a = Variable(real_center_key1_a, requires_grad=True)

                real_center_key2_idx_a = utils.farthest_point_sample(input_cropped1_a, 128, RAN=True)
                real_center_key2_a = utils.index_points(input_cropped1_a, real_center_key2_idx_a)
                real_center_key2_a = Variable(real_center_key2_a, requires_grad=True)


                loss_C_a = criterion_PointLoss(fake_recon_b, input_cropped1_b)
                # +alpha1*criterion_PointLoss(fake_center1_recon_b, real_center_key1_b)\
                # +alpha2*criterion_PointLoss(fake_center2_recon_b, real_center_key2_b)

                # loss_C_b = criterion_PointLoss(fake_recon_a, input_cropped1_a)
                loss_C_b = criterion_PointLoss(fake_recon_a, input_cropped1_a)
                # +alpha1*criterion_PointLoss(fake_center1_recon_a, real_center_key1_a)\
                # +alpha2*criterion_PointLoss(fake_center2_recon_a, real_center_key2_a)

                # loss_C_a_out = criterion_PointLoss(torch.squeeze(output_cropped1_a, 1), torch.squeeze(input_cropped1_a, 1))
                # loss_C_b_out = criterion_PointLoss(torch.squeeze(output_cropped1_b, 1), torch.squeeze(input_cropped1_b, 1))

                # loss_G = (loss_G_a2b + loss_G_b2a) + \
                #          (wgt_c_a * loss_C_a + wgt_c_b * loss_C_b) + \
                #          (wgt_c_a * loss_I_a + wgt_c_b * loss_I_b) * wgt_i
                #
                loss_G = (loss_G_a2b + loss_G_b2a) + (1 * (loss_C_a ) + 1 * (loss_C_b)) / 2


                # [input_cropped1_a, input_cropped2_a, input_cropped3_a]

                # errG_l2_a2b_out = criterion_PointLoss(torch.squeeze(recon_cropped1_b, 1), torch.squeeze(input_cropped1_a, 1)) \
                #           + alpha1 * criterion_PointLoss(torch.squeeze(recon_cropped2_b, 1), torch.squeeze(input_cropped2_a, 1)) \
                #           + alpha2 * criterion_PointLoss(torch.squeeze(recon_cropped3_b, 1), torch.squeeze(input_cropped3_a, 1))
                #
                # errG_l2_b2a_out = criterion_PointLoss(torch.squeeze(recon_cropped1_a, 1), torch.squeeze(input_cropped1_b, 1)) \
                #                  + alpha1 * criterion_PointLoss(torch.squeeze(recon_cropped2_a, 1), torch.squeeze(input_cropped2_b, 1)) \
                #                  + alpha2 * criterion_PointLoss(torch.squeeze(recon_cropped3_a, 1), torch.squeeze(input_cropped3_b, 1))

                print('save...')
                np.savetxt('./input_cropped1_a' + '.txt', input_cropped1_a[0, :, :].cpu().detach().numpy(),
                           fmt="%f,%f,%f")  # input_A
                np.savetxt('./input_cropped1_b' + '.txt', input_cropped1_b[0, :, :].cpu().detach().numpy(),
                           fmt="%f,%f,%f")  # input_B
                np.savetxt('./fake_out_a' + '.txt', fake_out_a[0, :, :].cpu().detach().numpy(),
                           fmt="%f,%f,%f")  # input_A
                np.savetxt('./fake_out_b' + '.txt', fake_out_b[0, :, :].cpu().detach().numpy(),
                           fmt="%f,%f,%f")  # input_B
                np.savetxt('./fake_recon_a' + '.txt', fake_recon_a[0, :, :].cpu().detach().numpy(),
                           fmt="%f,%f,%f")  # input_A
                np.savetxt('./fake_recon_b' + '.txt', fake_recon_b[0, :, :].cpu().detach().numpy(),
                           fmt="%f,%f,%f")  # input_B
                print('done')



                # errG_l2_ab_recon = criterion_PointLoss(torch.squeeze(fake_out_b, 1), torch.squeeze(real_center, 1)) \
                #                  + alpha1 * criterion_PointLoss(fake_center1_out_b, real_center_key1) \
                #                  + alpha2 * criterion_PointLoss(fake_center2, real_center_key2)
                # errG_l2_ba_recon = criterion_PointLoss(torch.squeeze(fake, 1), torch.squeeze(real_center, 1)) \
                #                  + alpha1 * criterion_PointLoss(fake_center1, real_center_key1) \
                #                  + alpha2 * criterion_PointLoss(fake_center2, real_center_key2)



                # errG = (1-0.95) * loss_G + 0.95 * (errG_l2_b2a_out + errG_l2_a2b_out)

                loss_G.backward()
                optimG.step()


                # get losses
                loss_G_a2b_train += [loss_G_a2b.item()]
                loss_G_b2a_train += [loss_G_b2a.item()]

                loss_D_a_train += [loss_D_a.item()]
                loss_D_b_train += [loss_D_b.item()]

                loss_C_a_train += [loss_C_a.item()]
                loss_C_b_train += [loss_C_b.item()]

                loss_CD +=[loss_G.item()]

                # if wgt_i > 0:
                #     loss_I_a_train += [loss_I_a.item()]
                #     loss_I_b_train += [loss_I_b.item()]

                # print('TRAIN: EPOCH %d: BATCH %04d/%04d: '
                #       'G_a2b: %.4f G_b2a: %.4f D_a: %.4f D_b: %.4f C_a: %.4f C_b: %.4f I_a: %.4f I_b: %.4f'
                print('TRAIN: EPOCH %d: BATCH %04d/%04d: '
                      'G_a2b: %.4f G_b2a: %.4f D_a: %.4f D_b: %.4f C_a: %.4f C_b: %.4f CD_loss: %.4f'
                      % (epoch, i, num_batch_train,
                         mean(loss_G_a2b_train), mean(loss_G_b2a_train),
                         mean(loss_D_a_train), mean(loss_D_b_train),
                         mean(loss_C_a_train), mean(loss_C_b_train), mean(loss_CD)))
                         # mean(loss_I_a_train), mean(loss_I_b_train)))

                # if should(num_freq_disp):
                #     ## show output
                #     input_a = transform_inv(input_a)
                #     output_a = transform_inv(output_a)
                #     input_b = transform_inv(input_b)
                #     output_b = transform_inv(output_b)
                #
                #     writer_train.add_images('input_a', input_a, num_batch_train * (epoch - 1) + i, dataformats='NHWC')
                #     writer_train.add_images('output_a', output_a, num_batch_train * (epoch - 1) + i, dataformats='NHWC')
                #     writer_train.add_images('input_b', input_b, num_batch_train * (epoch - 1) + i, dataformats='NHWC')
                #     writer_train.add_images('output_b', output_b, num_batch_train * (epoch - 1) + i, dataformats='NHWC')

            # writer_train.add_scalar('loss_G_a2b', mean(loss_G_a2b_train), epoch)
            # writer_train.add_scalar('loss_G_b2a', mean(loss_G_b2a_train), epoch)
            # writer_train.add_scalar('loss_D_a', mean(loss_D_a_train), epoch)
            # writer_train.add_scalar('loss_D_b', mean(loss_D_b_train), epoch)
            # writer_train.add_scalar('loss_C_a', mean(loss_C_a_train), epoch)
            # writer_train.add_scalar('loss_C_b', mean(loss_C_b_train), epoch)
            # writer_train.add_scalar('loss_I_a', mean(loss_I_a_train), epoch)
            # writer_train.add_scalar('loss_I_b', mean(loss_I_b_train), epoch)

            # # update schduler
            # # schedG.step()
            # # schedD.step()

            ## save
            if (epoch % num_freq_save) == 0:
                self.save(dir_chck, netG_a2b, netG_b2a, netD_a, netD_b, optimG, optimD, epoch)

        writer_train.close()

    def test(self):
        mode = self.mode

        batch_size = self.batch_size
        device = self.device
        gpu_ids = self.gpu_ids

        nch_in = self.nch_in
        nch_out = self.nch_out
        nch_ker = self.nch_ker

        norm = self.norm

        name_data = self.name_data

        ## setup dataset
        dir_chck = os.path.join(self.dir_checkpoint, self.scope, name_data)

        dir_result = os.path.join(self.dir_result, self.scope, name_data)
        dir_result_save = os.path.join(dir_result, 'images')
        if not os.path.exists(dir_result_save):
            os.makedirs(dir_result_save)

        dir_data_test = os.path.join(self.dir_data, self.name_data, 'test')

        transform_test = transforms.Compose([Normalize(), ToTensor()])
        transform_inv = transforms.Compose([ToNumpy(), Denomalize()])

        dataset_test = Dataset(dir_data_test, data_type=self.data_type, transform=transform_test)

        loader_test = torch.utils.data.DataLoader(dataset_test, batch_size=1, shuffle=False, num_workers=8)

        num_test = len(dataset_test)

        num_batch_test = int((num_test / 1) + ((num_test % 1) != 0))

        ## setup network
        # netG_a2b = UNet(nch_in, nch_out, nch_ker, norm)
        # netG_b2a = UNet(nch_in, nch_out, nch_ker, norm)
        netG_a2b = ResNet(nch_in, nch_out, nch_ker, norm, nblk=self.nblk)
        netG_b2a = ResNet(nch_in, nch_out, nch_ker, norm, nblk=self.nblk)

        init_net(netG_a2b, init_type='normal', init_gain=0.02, gpu_ids=gpu_ids)
        init_net(netG_b2a, init_type='normal', init_gain=0.02, gpu_ids=gpu_ids)

        ## load from checkpoints
        st_epoch = 0

        netG_a2b, netG_b2a, st_epoch = self.load(dir_chck, netG_a2b, netG_b2a, mode=mode)

        ## test phase
        with torch.no_grad():
            netG_a2b.eval()
            netG_b2a.eval()
            # netG_a2b.train()
            # netG_b2a.train()

            gen_loss_l1_test = 0
            for i, data in enumerate(loader_test, 1):
                input_a = data['dataA'].to(device)
                input_b = data['dataB'].to(device)

                # forward netG
                output_b = netG_a2b(input_a)
                output_a = netG_b2a(input_b)

                recon_b = netG_a2b(output_a)
                recon_a = netG_b2a(output_b)

                input_a = transform_inv(input_a)
                input_b = transform_inv(input_b)
                output_a = transform_inv(output_a)
                output_b = transform_inv(output_b)
                recon_a = transform_inv(recon_a)
                recon_b = transform_inv(recon_b)

                for j in range(input_a.shape[0]):
                    name = 1 * (i - 1) + j
                    fileset = {'name': name,
                               'input_a': "%04d-input_a.png" % name,
                               'input_b': "%04d-input_b.png" % name,
                               'output_a': "%04d-output_a.png" % name,
                               'output_b': "%04d-output_b.png" % name,
                               'recon_a': "%04d-recon_a.png" % name,
                               'recon_b': "%04d-recon_b.png" % name}

                    plt.imsave(os.path.join(dir_result_save, fileset['input_a']), input_a[j, :, :, :].squeeze())
                    plt.imsave(os.path.join(dir_result_save, fileset['input_b']), input_b[j, :, :, :].squeeze())
                    plt.imsave(os.path.join(dir_result_save, fileset['output_a']), output_a[j, :, :, :].squeeze())
                    plt.imsave(os.path.join(dir_result_save, fileset['output_b']), output_b[j, :, :, :].squeeze())
                    plt.imsave(os.path.join(dir_result_save, fileset['recon_a']), recon_a[j, :, :, :].squeeze())
                    plt.imsave(os.path.join(dir_result_save, fileset['recon_b']), recon_b[j, :, :, :].squeeze())

                    append_index(dir_result, fileset)

                    print("%d / %d" % (name + 1, num_test))


def set_requires_grad(nets, requires_grad=False):
    """Set requies_grad=Fasle for all the networks to avoid unnecessary computations
    Parameters:
        nets (network list)   -- a list of networks
        requires_grad (bool)  -- whether the networks require gradients or not
    """
    if not isinstance(nets, list):
        nets = [nets]
    for net in nets:
        if net is not None:
            for param in net.parameters():
                param.requires_grad = requires_grad


def get_scheduler(optimizer, opt):
    """Return a learning rate scheduler

    Parameters:
        optimizer          -- the optimizer of the network
        opt (option class) -- stores all the experiment flags; needs to be a subclass of BaseOptions．　
                              opt.lr_policy is the name of learning rate policy: linear | step | plateau | cosine

    For 'linear', we keep the same learning rate for the first <opt.n_epochs> epochs
    and linearly decay the rate to zero over the next <opt.n_epochs_decay> epochs.
    For other schedulers (step, plateau, and cosine), we use the default PyTorch schedulers.
    See https://pytorch.org/docs/stable/optim.html for more details.
    """
    if opt.lr_policy == 'linear':
        def lambda_rule(epoch):
            lr_l = 1.0 - max(0, epoch + opt.epoch_count - opt.n_epochs) / float(opt.n_epochs_decay + 1)
            return lr_l
        scheduler = lr_scheduler.LambdaLR(optimizer, lr_lambda=lambda_rule)
    elif opt.lr_policy == 'step':
        scheduler = lr_scheduler.StepLR(optimizer, step_size=opt.lr_decay_iters, gamma=0.1)
    elif opt.lr_policy == 'plateau':
        scheduler = lr_scheduler.ReduceLROnPlateau(optimizer, mode='min', factor=0.2, threshold=0.01, patience=5)
    elif opt.lr_policy == 'cosine':
        scheduler = lr_scheduler.CosineAnnealingLR(optimizer, T_max=opt.n_epochs, eta_min=0)
    else:
        return NotImplementedError('learning rate policy [%s] is not implemented', opt.lr_policy)
    return scheduler


def append_index(dir_result, fileset, step=False):
    index_path = os.path.join(dir_result, "index.html")
    if os.path.exists(index_path):
        index = open(index_path, "a", encoding='cp949')
    else:
        index = open(index_path, "w", encoding='cp949')
        index.write("<html><body><table><tr>")
        if step:
            index.write("<th>step</th>")
        for key, value in fileset.items():
            index.write("<th>%s</th>" % key)
        index.write('</tr>')

    # for fileset in filesets:
    index.write("<tr>")

    if step:
        index.write("<td>%d</td>" % fileset["step"])
    index.write("<td>%s</td>" % fileset["name"])

    del fileset['name']

    for key, value in fileset.items():
        index.write("<td><img src='images/%s'></td>" % value)

    index.write("</tr>")
    return index_path


def add_plot(output, label, writer, epoch=[], ylabel='Density', xlabel='Radius', namescope=[]):
    fig, ax = plt.subplots()

    ax.plot(output.transpose(1, 0).detach().numpy(), '-')
    ax.plot(label.transpose(1, 0).detach().numpy(), '--')

    ax.set_xlim(0, 400)

    ax.grid(True)
    ax.set_ylabel(ylabel)
    ax.set_xlabel(xlabel)

    writer.add_figure(namescope, fig, epoch)
